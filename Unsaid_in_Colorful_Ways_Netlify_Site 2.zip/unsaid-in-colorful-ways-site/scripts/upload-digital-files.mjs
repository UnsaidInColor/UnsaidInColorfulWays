import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { getStore } from '@netlify/blobs';

// Run after linking this project to a Netlify site and authenticating with the Netlify CLI.
// Only files in private-downloads are uploaded to the private Blob store; they are not public website assets.
const store = getStore({ name: 'private-digital-downloads', consistency: 'strong' });
const files = [
  { path: 'private-downloads/a-language-of-our-own.zip', key: 'a-language-of-our-own.zip' },
  { path: 'private-downloads/uncontained.zip', key: 'uncontained.zip' }
];
for (const file of files) {
  try {
    const bytes = await readFile(resolve(file.path));
    await store.set(file.key, bytes, { metadata: { uploadedBy: 'Unsaid in Colorful Ways site setup' } });
    console.log(`Uploaded private file: ${file.key} (${bytes.length} bytes)`);
  } catch (error) {
    if (error.code === 'ENOENT') console.log(`Skipped ${file.path}: file not supplied yet. Add it after confirming the final digital product file.`);
    else throw error;
  }
}
