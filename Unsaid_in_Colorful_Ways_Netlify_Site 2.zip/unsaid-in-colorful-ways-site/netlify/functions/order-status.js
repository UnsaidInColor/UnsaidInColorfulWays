const Stripe = require('stripe');
const DIGITAL = new Set(['language-digital', 'uncontained-digital']);
const json = (statusCode, body) => ({ statusCode, headers: { 'content-type': 'application/json', 'cache-control': 'no-store' }, body: JSON.stringify(body) });
exports.handler = async (event) => {
  if (event.httpMethod !== 'GET') return json(405, { error: 'Use GET.' });
  const id = event.queryStringParameters?.session_id;
  if (!id || !id.startsWith('cs_')) return json(400, { error: 'A valid checkout session reference is required.' });
  if (!process.env.STRIPE_SECRET_KEY) return json(503, { error: 'Stripe is not configured on this site yet.' });
  try {
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
    const session = await stripe.checkout.sessions.retrieve(id);
    const product = session.metadata?.product_slug;
    return json(200, { payment_status: session.payment_status, product, download_available: session.payment_status === 'paid' && DIGITAL.has(product) });
  } catch (error) {
    console.error('Stripe order verification failed:', error.message);
    return json(400, { error: 'The checkout session could not be verified.' });
  }
};
