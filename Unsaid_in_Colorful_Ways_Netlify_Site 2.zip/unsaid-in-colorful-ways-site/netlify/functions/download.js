const Stripe = require('stripe');
const { getStore } = require('@netlify/blobs');
const DOWNLOADS = {
  'language-digital': { key: 'a-language-of-our-own.zip', filename: 'A_Language_of_Our_Own_Print_Files.zip', type: 'application/zip' },
  'uncontained-digital': { key: 'uncontained.zip', filename: 'Uncontained_Digital_Print.zip', type: 'application/zip' }
};
const json = (statusCode, body) => ({ statusCode, headers: { 'content-type': 'application/json', 'cache-control': 'no-store' }, body: JSON.stringify(body) });
exports.handler = async (event) => {
  if (event.httpMethod !== 'GET') return json(405, { error: 'Use GET.' });
  const id = event.queryStringParameters?.session_id;
  if (!id || !id.startsWith('cs_')) return json(400, { error: 'A valid checkout session reference is required.' });
  if (!process.env.STRIPE_SECRET_KEY) return json(503, { error: 'Stripe is not configured.' });
  try {
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
    const session = await stripe.checkout.sessions.retrieve(id);
    if (session.payment_status !== 'paid') return json(403, { error: 'Payment has not been confirmed. No download is available.' });
    const file = DOWNLOADS[session.metadata?.product_slug];
    if (!file) return json(403, { error: 'This order does not include a digital download.' });
    const store = getStore({ name: 'private-digital-downloads', consistency: 'strong' });
    const bytes = await store.get(file.key, { type: 'arrayBuffer' });
    if (!bytes) return json(404, { error: 'The private download file has not been uploaded yet. Please contact the artist; do not purchase again.' });
    return { statusCode: 200, isBase64Encoded: true, headers: { 'content-type': file.type, 'content-disposition': `attachment; filename="${file.filename}"`, 'cache-control': 'private, no-store', 'x-content-type-options': 'nosniff' }, body: Buffer.from(bytes).toString('base64') };
  } catch (error) {
    console.error('Private digital download failed:', error.message);
    return json(400, { error: 'The order could not be verified or the private download is unavailable.' });
  }
};
