const Stripe = require('stripe');
const { getStore } = require('@netlify/blobs');
const PRODUCTS = {
  'language-digital': { priceEnv: 'STRIPE_PRICE_LANGUAGE_DIGITAL', kind: 'digital', downloadKey: 'a-language-of-our-own.zip' },
  'uncontained-digital': { priceEnv: 'STRIPE_PRICE_UNCONTAINED_DIGITAL', kind: 'digital', downloadKey: 'uncontained.zip' },
  'physical-print': { priceEnv: 'STRIPE_PRICE_PHYSICAL_PRINT', kind: 'physical' }
};
const json = (statusCode, body) => ({ statusCode, headers: { 'content-type': 'application/json', 'cache-control': 'no-store' }, body: JSON.stringify(body) });
exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Use POST to start checkout.' });
  if (!process.env.STRIPE_SECRET_KEY) return json(503, { error: 'Stripe is not configured yet. No payment has been taken.' });
  let body; try { body = JSON.parse(event.body || '{}'); } catch { return json(400, { error: 'Invalid request.' }); }
  const product = PRODUCTS[body.product];
  if (!product) return json(400, { error: 'Unknown product.' });
  const price = process.env[product.priceEnv];
  if (!price) return json(503, { error: `Missing ${product.priceEnv}. No payment has been taken.` });
  if (product.kind === 'digital') {
    try {
      const store = getStore({ name: 'private-digital-downloads', consistency: 'strong' });
      const metadata = await store.getMetadata(product.downloadKey);
      if (!metadata) return json(503, { error: 'This digital file is not ready for delivery yet. No payment has been taken.' });
    } catch (error) {
      console.error('Private download readiness check failed:', error.message);
      return json(503, { error: 'Secure download storage is not ready yet. No payment has been taken.' });
    }
  }
  const origin = process.env.URL || process.env.DEPLOY_PRIME_URL;
  if (!origin) return json(500, { error: 'Site URL is missing from the deployment environment.' });
  try {
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      line_items: [{ price, quantity: 1 }],
      success_url: `${origin}/success.html?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${origin}/cancel.html`,
      client_reference_id: body.product,
      metadata: { product_slug: body.product, fulfillment_kind: product.kind },
      payment_method_types: ['card'],
      ...(product.kind === 'physical' ? { shipping_address_collection: { allowed_countries: ['US'] } } : {})
    });
    return json(200, { url: session.url });
  } catch (error) {
    console.error('Stripe Checkout session creation failed:', error.message);
    return json(502, { error: 'Checkout could not be started. Please try later or contact the artist.' });
  }
};
