# Unsaid in Colorful Ways — launch and payment setup

This is a custom-coded static site with Netlify Functions prepared for Stripe Checkout and private digital downloads. **The site is not live and payments are not connected yet.** No Stripe keys, live Price IDs, merchant credentials, or Netlify account access were supplied, so no payment is claimed to work until you configure and test it.

## What is included

- Responsive art gallery, shop-first homepage, artist statement, contact link, and poetry-room preview.
- Five supplied painting photographs in `public/assets/`. They are displayed as supplied; no artwork was generated or painted over.
- Clearly marked placeholder titles for the paintings that have not been titled/confirmed.
- Stripe Checkout server function (`netlify/functions/create-checkout.js`). It refuses to start checkout when credentials or a product Price ID are missing.
- Order-status verification against Stripe and a private-download function. Downloads are not placed in the public website folder.
- Private digital files are served from Netlify Blobs only after the function verifies that Stripe says the matching Checkout Session is paid.
- `private-downloads/a-language-of-our-own.zip` is the existing 6×4, 8×6, and 12×9 300-DPI print pack. `uncontained.zip` is intentionally absent until the final download file is confirmed.

## Important safety note

The website's public directory is only `public/`. Do not change `netlify.toml` to publish the project root: the project root contains the private download source and must not be deployed as a public folder. Keep all secret keys in Netlify environment variables, never in HTML or JavaScript.

## Step 1 — create your Stripe products

1. Create/sign in to your Stripe account. Start in **test mode**.
2. In Stripe, create one-time products/prices for each product you actually intend to sell. Use the same currency and amount you choose for the listing. Do not guess prices; set them yourself.
3. Copy each Stripe **Price ID** (it begins `price_`) and set these environment variables in Netlify:
   - `STRIPE_PRICE_LANGUAGE_DIGITAL` — A Language of Our Own digital print pack.
   - `STRIPE_PRICE_UNCONTAINED_DIGITAL` — Uncontained digital pack; create this only after the final file and product details are ready.
   - `STRIPE_PRICE_PHYSICAL_PRINT` — physical print placeholder. Configure shipping/fulfillment details and the actual product variants before selling.
4. Add `STRIPE_SECRET_KEY` using your Stripe **test secret key** (`sk_test_...`) for initial tests. Do not put this key in the browser code or share it in chat.
5. Deploy/redeploy after environment variable changes.

The current physical print example collects a US shipping address, but it is only a basic single-price placeholder. It does not yet support size/frame variants, shipping rates, tax configuration, inventory, or order-management emails. Do not enable that product until those business choices are configured in Stripe and tested.

## Step 2 — deploy to Netlify

1. Create a free Netlify account and a new site from this folder/repository, or use the Netlify CLI.
2. Install Node.js 20 or newer, then run `npm install` in the project folder.
3. Authenticate/link with Netlify (`npx netlify login`, then `npx netlify link`).
4. For local testing, run `npm run dev`. For a deployment, run `npx netlify deploy --build` for a draft deploy, then `npx netlify deploy --prod --build` when ready. The Netlify UI can also deploy from a connected Git repository.
5. Set the environment variables in the Netlify UI under the site's environment variable settings. The site uses `public/` as its publish directory and `netlify/functions/` for server functions.

## Step 3 — upload private digital files

The supplied A Language of Our Own print pack is in the project's `private-downloads/` directory and is **not in `public/`**. After linking/authenticating with Netlify and installing dependencies, run:

```bash
npm run upload:downloads
```

This uploads files to the private Netlify Blobs store named `private-digital-downloads`. The `uncontained.zip` upload is skipped until you add that exact file to `private-downloads/` after confirming the final downloadable asset. For a local upload script, make sure the Netlify CLI authentication context and the `NETLIFY_SITE_ID` plus `NETLIFY_AUTH_TOKEN` environment variables are available to that shell; never put the token in the repository. Do not upload a mockup as a print file. Confirm the correct file, image quality, allowed ratios, and customer usage terms before selling. Checkout also checks that a digital file exists in private storage before creating a payment session, so a missing file should not result in an accepted purchase.

## Step 4 — test the entire purchase flow in Stripe test mode

Before going live, test all of these:

- A configured digital product redirects to Stripe Checkout and shows the correct product, price, and currency.
- A successful test payment returns to `success.html`, where the site verifies the Stripe session server-side.
- A paid A Language of Our Own order receives the correct ZIP from the private Blob store.
- A missing/invalid session, unpaid session, or unrelated product cannot download the file.
- Cancelling checkout returns to `cancel.html` and no payment is recorded.
- Missing Stripe configuration produces a clear error and does not claim that payment succeeded.
- The site works on a phone and desktop.

Then switch to Stripe live mode, create/copy the **live-mode** Price IDs, set the live secret key securely in Netlify, redeploy, and make a real low-value test purchase only when you are ready. Test your actual customer receipt and delivery process. Do not advertise the shop as open before all of these pass.

## Known limitations before launch

- No payment provider or Netlify account has been connected from this chat; setup and real-world test transactions remain to be done by you in your accounts.
- The site currently supports card checkout. Apple Pay availability depends on Stripe configuration, browser/device eligibility, domain verification, and Stripe account settings; it is not promised or marked as enabled.
- Digital files are downloadable on the order confirmation page after server-side payment verification. This package does not yet send a separate automated email receipt/download link.
- Only the A Language of Our Own print pack is supplied as a private digital asset. No Uncontained downloadable pack was invented.
- Physical print size/frame choices, shipping, tax, pricing, stock, and fulfillment still need final decisions.
- The poetry section is labeled as a preview because original poem text has not been added to this package. The artist statement is a draft based on the artist's previously shared description.
- Hosting may be free within Netlify's current limits; Stripe processing fees and any purchased domain are separate costs.

## Contact

The site's contact link uses `Versatileimpressionz@gmail.com`. Test the mail link before launch.
