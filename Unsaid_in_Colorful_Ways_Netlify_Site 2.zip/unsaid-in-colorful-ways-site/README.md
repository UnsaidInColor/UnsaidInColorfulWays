# Unsaid in Colorful Ways

Custom-coded, responsive art and poetry studio website built with HTML, CSS, JavaScript, Netlify Functions, Stripe Checkout, and private Netlify Blobs digital delivery.

- Start with `SETUP.md` for the payment and Netlify launch checklist.
- Public site files are in `public/`.
- Server-side payment/download functions are in `netlify/functions/`.
- Private digital source files are in `private-downloads/` and must never be served as public assets.
- Configure real Stripe keys and Price IDs in Netlify environment variables. They are deliberately not included here.

**Payment status:** not connected or tested against a real Stripe/Netlify account. No orders should be accepted until the setup and test checklist passes.
